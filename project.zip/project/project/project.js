let img = document.querySelector('.img');
let container =document.querySelector('.container')
function phones(src){
    img.src=src;
}
function colors(color){
container.style.background=color;
}

